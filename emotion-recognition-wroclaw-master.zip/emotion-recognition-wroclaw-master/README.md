# Emotion detection classifier in browser

## Requirements
TODO:s
